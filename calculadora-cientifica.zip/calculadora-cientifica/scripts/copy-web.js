/* Copia los archivos web a www/ (la carpeta que empaqueta Capacitor). */
'use strict';
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const out = path.join(root, 'www');
const FILES = ['index.html', 'styles.css', 'script.js', 'manifest.webmanifest', 'sw.js'];
const DIRS = ['icons'];

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
FILES.forEach((f) => fs.copyFileSync(path.join(root, f), path.join(out, f)));
DIRS.forEach((d) => fs.cpSync(path.join(root, d), path.join(out, d), { recursive: true }));
console.log(`Copiado a ${out}: ${[...FILES, ...DIRS.map((d) => d + '/')].join(', ')}`);
