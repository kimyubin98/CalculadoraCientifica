/* Pruebas de la calculadora. Ejecutar con:  node tests.js */
'use strict';

const { evaluate, formatNumber, CalcError, Calculator, keyToAction } = require('./script.js');

let passed = 0;
let failed = 0;

function report(ok, name, detail) {
  if (ok) passed += 1; else failed += 1;
  console.log(`${ok ? 'OK  ' : 'FALLA'}  ${name}${detail ? `  →  ${detail}` : ''}`);
}

/** Evalúa y compara el resultado ya formateado. */
function expectValue(name, expr, expected, mode = 'DEG') {
  try {
    const got = formatNumber(evaluate(expr, { angleMode: mode }));
    report(got === expected, name, `${expr} = ${got}${got === expected ? '' : ` (esperado ${expected})`}`);
  } catch (err) {
    report(false, name, `${expr} lanzó: ${err.message}`);
  }
}

/** Comprueba que se lance un CalcError con mensaje comprensible. */
function expectError(name, expr, fragment, mode = 'DEG') {
  try {
    const got = evaluate(expr, { angleMode: mode });
    report(false, name, `${expr} devolvió ${got} en lugar de error`);
  } catch (err) {
    const ok = err instanceof CalcError && err.message.includes(fragment);
    report(ok, name, `${expr} → «${err.message}»`);
  }
}

/** Simula pulsaciones de teclado físico sobre la calculadora. */
function typeKeys(calc, keys) {
  for (const key of keys) {
    const mapped = keyToAction(key);
    if (mapped) calc.press(mapped[0], mapped[1]);
  }
  return calc;
}

console.log('— Pruebas obligatorias del enunciado —');
expectValue('1. Suma', '25+15', '40');
expectValue('2. División', '10÷4', '2.5');
expectValue('3. Cuadrado', '5^2', '25');
expectValue('4. Raíz cuadrada', '√(81)', '9');
expectValue('5. log(100)', 'log(100)', '2');
expectValue('6. ln(e)', 'ln(e)', '1');
expectValue('7. sin(30°) DEG', 'sin(30)', '0.5');
expectValue('8. cos(60°) DEG', 'cos(60)', '0.5');
expectValue('9. tan(45°) DEG', 'tan(45)', '1');
expectValue('10. Factorial', '5!', '120');
expectValue('11. Potencia', '2^3', '8');
expectError('12. División entre cero', '1÷0', 'No se puede dividir entre cero');
expectError('13. log de negativo', 'log(−10)', 'log solo está definido');
expectValue('14a. Prioridad (× antes que +)', '2+3×4', '14');
expectValue('14b. Prioridad (^ antes que ×)', '2×3^2', '18');
expectValue('14c. Menos unario con potencia', '−2^2', '-4');
expectValue('15a. Paréntesis', '(2+3)×4', '20');
expectValue('15b. Paréntesis anidados', '((1+2)×(3+4))÷7', '3');

console.log('\n— Encadenado a partir del resultado (obligatoria 16) —');
{
  const c = typeKeys(new Calculator(), '2+3');
  c.press('equals');
  report(c.result === '5', '16a. 2+3 = 5', c.result);
  typeKeys(c, '*4');
  c.press('equals');
  report(c.result === '20', '16b. Continuar: ×4 sobre el resultado → 20', c.result);
  c.press('post', 'sq');
  c.press('equals');
  report(c.result === '400', '16c. x² sobre el resultado → 400', c.result);
  c.press('fn', 'sqrt');
  c.press('equals');
  report(c.result === '20', '16d. √ aplicada al resultado → 20', c.result);
  typeKeys(c, '7');
  report(c.expr === '7' && !c.justEvaluated, '16e. Un dígito tras "=" inicia operación nueva', c.expr);
}

console.log('\n— DEG / RAD —');
expectValue('sin(π/2) en RAD', 'sin(π÷2)', '1', 'RAD');
expectValue('sin(π) en RAD = 0', 'sin(π)', '0', 'RAD');
expectValue('sin(90) en DEG', 'sin(90)', '1', 'DEG');
expectValue('cos(π) en RAD', 'cos(π)', '-1', 'RAD');
expectValue('tan(π/4) en RAD', 'tan(π÷4)', '1', 'RAD');
expectValue('asin(0.5) en DEG', 'asin(0.5)', '30', 'DEG');
expectValue('acos(0.5) en DEG', 'acos(0.5)', '60', 'DEG');
expectValue('atan(1) en DEG', 'atan(1)', '45', 'DEG');
expectValue('atan(1) en RAD', 'atan(1)', '0.785398163397448', 'RAD');
expectValue('sin(1) DEG ≠ sin(1) RAD (DEG)', 'sin(1)', '0.0174524064372835', 'DEG');
expectValue('sin(1) DEG ≠ sin(1) RAD (RAD)', 'sin(1)', '0.841470984807897', 'RAD');
{
  const c = typeKeys(new Calculator(), 's30)');
  c.press('equals');
  const deg = c.result;
  c.press('mode', 'RAD');
  const rad = c.result;
  c.press('mode', 'DEG');
  report(deg === '0.5' && rad === '-0.988031624092862' && c.result === '0.5',
    'Alternar DEG↔RAD recalcula el resultado mostrado', `DEG=${deg}  RAD=${rad}  DEG de nuevo=${c.result}`);
}
expectError('tan(90°) indefinida', 'tan(90)', 'no está definida');
expectError('tan(π/2) indefinida en RAD', 'tan(π÷2)', 'no está definida', 'RAD');

console.log('\n— Funciones científicas adicionales —');
expectValue('Raíz enésima 3ʸ√27', '3ʸ√27', '3');
expectValue('Raíz enésima 4ʸ√16', '4ʸ√16', '2');
expectValue('Raíz cúbica de negativo', '3ʸ√(−8)', '-2');
expectValue('Inverso 4^(−1)', '4^(−1)', '0.25');
expectValue('Valor absoluto', 'abs(−7.5)', '7.5');
expectValue('Constante π', 'π', '3.14159265358979');
expectValue('Constante e', 'e', '2.71828182845905');
expectValue('Notación científica 1.5E3', '1.5E3', '1500');
expectValue('Notación científica 2E-3', '2E-3', '0.002');
expectValue('Porcentaje 50%', '50%', '0.5');
expectValue('Porcentaje 200×10%', '200×10%', '20');
expectValue('Factorial 0!', '0!', '1');
expectValue('Factorial 20!', '20!', '2.43290200817664E18');
expectValue('Factorial 170!', '170!', '7.25741561530799E306');
expectValue('Multiplicación implícita 2π', '2π', '6.28318530717959');
expectValue('Multiplicación implícita 2(3+4)', '2(3+4)', '14');
expectValue('Potencia asociativa a la derecha', '2^3^2', '512');
expectValue('Exponente negativo', '2^−2', '0.25');
expectValue('Paréntesis sin cerrar se autocierran', '(2+3', '5');

console.log('\n— Precisión de coma flotante —');
expectValue('0.1+0.2', '0.1+0.2', '0.3');
expectValue('0.1+0.2−0.3 = 0', '0.1+0.2−0.3', '0');
expectValue('1.1×1.1', '1.1×1.1', '1.21');
expectValue('1÷3', '1÷3', '0.333333333333333');
expectValue('Número grande en notación científica', '10^20', '1E20');
expectValue('Número pequeño en notación científica', '10^(−8)', '1E-8');

console.log('\n— Errores matemáticos (mensajes comprensibles) —');
expectError('0÷0', '0÷0', 'No se puede dividir entre cero');
expectError('Raíz de negativo', '√(−4)', 'no es real');
expectError('log(0)', 'log(0)', 'mayores que 0');
expectError('ln(−1)', 'ln(−1)', 'mayores que 0');
expectError('asin(2)', 'asin(2)', 'entre −1 y 1');
expectError('acos(−1.5)', 'acos(−1.5)', 'entre −1 y 1');
expectError('Factorial de negativo', '(−3)!', 'enteros no negativos');
expectError('Factorial decimal', '2.5!', 'enteros no negativos');
expectError('Factorial 171!', '171!', 'hasta 170!');
expectError('Desbordamiento 10^400', '10^400', 'desbordamiento');
expectError('0^(−1)', '0^(−1)', 'dividir entre cero');
expectError('0^0', '0^0', 'indeterminada');
expectError('(−8)^0.5', '(−8)^0.5', 'no tiene resultado real');
expectError('Raíz índice 0', '0ʸ√5', 'no puede ser 0');
expectError('Raíz par de negativo', '2ʸ√(−9)', 'No existe la raíz real');
expectError('Expresión incompleta', '2+', 'incompleta');
expectError('Operador suelto', '*5', 'Se esperaba un número');
expectError('Paréntesis sin abrir', '2+3)', 'sin su paréntesis de apertura');
expectError('Paréntesis vacíos', '()', 'Se esperaba un número');
expectError('Falta paréntesis tras función', 'sin30', 'Falta «(»');
expectError('Exponente incompleto', '2E', 'incompleta');
expectError('Dos puntos decimales', '1.2.3', 'dos puntos decimales');

console.log('\n— Seguridad: la entrada nunca se ejecuta como código —');
expectError('Código JS: alert(1)', 'alert(1)', 'desconocido');
expectError('Código JS: process.exit()', 'process.exit()', 'desconocido');
expectError('Código JS: 1;2', '1;2', 'Carácter no válido');
expectError('Código JS: constructor', 'constructor', 'desconocido');
expectError('Código JS: (1).constructor', '(1).constructor', 'Número mal formado');
expectError('Cadena con comillas', '"a"', 'Carácter no válido');
expectError('Expresión demasiado larga', '1+'.repeat(300) + '1', 'demasiado larga');
{
  let threw = false;
  try { evaluate('('.repeat(250) + '1' + ')'.repeat(250)); } catch (e) { threw = true; }
  report(!threw, 'Anidamiento profundo (250 paréntesis) no rompe la aplicación');
}
{
  const src = require('fs').readFileSync(require('path').join(__dirname, 'script.js'), 'utf8');
  const code = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  report(!/\beval\s*\(/.test(code) && !/new\s+Function\b/.test(code) && !/\bFunction\s*\(/.test(code),
    'script.js no contiene eval() ni new Function()');
}

console.log('\n— Reglas de entrada (estado) —');
{
  const c = typeKeys(new Calculator(), '2+*3');
  report(c.expr === '2×3', 'Un operador sustituye al anterior', c.expr);
}
{
  const c = typeKeys(new Calculator(), '5*-3');
  c.press('equals');
  report(c.result === '-15', 'Signo negativo tras un operador: 5×−3 = −15', c.result);
}
{
  const c = typeKeys(new Calculator(), '1.5.2');
  report(c.expr === '1.52', 'No admite dos puntos decimales en un mismo número', c.expr);
}
{
  const c = typeKeys(new Calculator(), '007');
  report(c.expr === '7', 'Los ceros a la izquierda se normalizan', c.expr);
}
{
  const c = typeKeys(new Calculator(), '5');
  c.press('sign');
  const a = c.expr;
  c.press('sign');
  report(a === '−5' && c.expr === '5', 'Cambio de signo (±) alterna', `${a} → ${c.expr}`);
}
{
  const c = typeKeys(new Calculator(), '5+3');
  c.press('sign');
  c.press('equals');
  report(c.result === '2', '5+3 con ± en el último número → 5+(−3) = 2', c.result);
}
{
  const c = typeKeys(new Calculator(), 's30');
  c.press('back');
  c.press('back');
  c.press('back');
  report(c.expr === '', 'Retroceso borra "sin(" completo', JSON.stringify(c.expr));
}
{
  const c = typeKeys(new Calculator(), '2+3');
  c.press('equals');
  c.press('back');
  report(c.expr === '2+' && !c.justEvaluated, 'Retroceso tras "=" edita la expresión original', c.expr);
}
{
  const c = typeKeys(new Calculator(), '9/0');
  c.press('equals');
  const err = c.error;
  typeKeys(c, '\u0008');
  c.press('back');
  c.press('digit', '4');
  c.press('equals');
  report(err.includes('dividir entre cero') && c.result === '2.25' && c.error === '',
    'Tras un error se puede corregir y seguir calculando', `error="${err}", luego 9/4 = ${c.result}`);
}
{
  const c = typeKeys(new Calculator(), '5');
  c.press('post', 'sq');
  c.press('equals');
  report(c.result === '25', 'Botón x² (5 → 25)', c.result);
}
{
  const c = typeKeys(new Calculator(), '4');
  c.press('post', 'inv');
  c.press('equals');
  report(c.result === '0.25', 'Botón 1/x (4 → 0.25)', c.result);
}
{
  const c = typeKeys(new Calculator(), '3');
  c.press('op', 'ʸ√');
  typeKeys(c, '27');
  c.press('equals');
  report(c.result === '3', 'Botón ʸ√x (3 ʸ√ 27 → 3)', c.result);
}
{
  const c = typeKeys(new Calculator(), '2');
  c.press('const', 'π');
  c.press('equals');
  report(c.expr === '2×π' && c.result === '6.28318530717959', 'Constante tras número inserta ×', `${c.expr} = ${c.result}`);
}
{
  const c = typeKeys(new Calculator(), '1.5');
  c.press('exp');
  typeKeys(c, '3');
  c.press('equals');
  report(c.result === '1500', 'Botón EXP (1.5 EXP 3 → 1500)', c.result);
}
{
  const c = typeKeys(new Calculator(), '5');
  c.press('post', '!');
  c.press('equals');
  report(c.result === '120', 'Botón n! (5 → 120)', c.result);
}
{
  const c = typeKeys(new Calculator(), '(2+3');
  c.press('equals');
  report(c.expr === '(2+3)' && c.result === '5', 'Igual autocierra paréntesis y los muestra', `${c.expr} = ${c.result}`);
}
{
  const c = typeKeys(new Calculator(), '8');
  c.press('clear');
  report(c.expr === '' && c.result === '' && !c.error, 'AC limpia todo');
}
{
  const v = typeKeys(new Calculator(), '2+3').getView();
  report(v.isPreview && v.main === '5', 'Vista previa en vivo mientras se escribe', JSON.stringify(v.main));
}

console.log('\n— Teclado físico —');
{
  const expected = {
    '7': ['digit', '7'], '+': ['op', '+'], '-': ['op', '−'], '*': ['op', '×'], '/': ['op', '÷'],
    '^': ['op', '^'], Enter: ['equals'], Escape: ['clear'], Backspace: ['back'], p: ['const', 'π'],
    '(': ['open'], ')': ['close'], '.': ['decimal'], ',': ['decimal'], '%': ['post', '%'], '!': ['post', '!'],
  };
  const bad = Object.entries(expected).filter(([k, v]) => JSON.stringify(keyToAction(k)) !== JSON.stringify(v));
  report(bad.length === 0, 'Mapa de teclas (dígitos, operadores, Enter, Esc, Retroceso…)', bad.map(([k]) => k).join(' '));
  report(keyToAction('constructor') === null && keyToAction('F5') === null, 'Teclas no mapeadas se ignoran');
}

console.log(`\nResultado: ${passed} correctas, ${failed} fallidas, ${passed + failed} en total.`);
process.exit(failed === 0 ? 0 : 1);
