# Calculadora científica

HTML5 + CSS3 + JavaScript (ES6+), sin dependencias ni servidor.

## Estructura

```
calculadora-cientifica/
├── index.html   Estructura y botones
├── styles.css   Diseño (oscuro por defecto, claro opcional, adaptable)
├── script.js    Motor matemático + estado + interfaz
├── tests.js     Pruebas automáticas (Node)
├── manifest.webmanifest, sw.js, icons/   PWA instalable y sin conexión
├── package.json, capacitor.config.json, scripts/   Empaquetado Android (Capacitor)
├── ANDROID.md   Cómo instalarla / generar el APK
└── README.md
```

## Ejecutar

- Abre `index.html` en un navegador moderno (doble clic). No requiere servidor.
- Pruebas (opcional): `node tests.js`

## Teclado

| Tecla | Acción | Tecla | Acción |
|---|---|---|---|
| `0-9` `.` `,` | Dígitos y decimal | `Enter` `=` | Calcular |
| `+ - * x /` | Operadores | `Esc` `Supr` | Limpiar todo |
| `^` | Potencia | `Retroceso` | Borrar último carácter |
| `r` | Raíz enésima (`3 ʸ√ 27 = 3`) | `( )` | Paréntesis |
| `q` | √ | `%` `!` | Porcentaje, factorial |
| `s c t` | sin, cos, tan | `l n a` | log, ln, abs |
| `p` `e` | π, e | `E` (mayúscula) | Notación científica |
| `d` | Alternar DEG/RAD | | |

## Límites y convenciones

- Precisión: 15 cifras significativas (la aritmética intermedia usa 16).
- Factorial: enteros de 0 a 170.
- Números ≥ 1e15 o < 1e-6 se muestran como `1.5E15`; en la entrada, la notación científica usa `E` mayúscula (`e` minúscula es la constante de Euler).
- `%` divide entre 100 (`50%` = 0.5; `200×10%` = 20).
- `0^0` se trata como indeterminado y devuelve error.
- Solo números reales (sin complejos).
- Longitud máxima de la expresión: 200 caracteres.
